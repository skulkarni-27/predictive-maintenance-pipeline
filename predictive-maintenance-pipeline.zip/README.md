# Predictive Maintenance ML Pipeline

Automated ML pipeline with GitHub Actions.

## Setup
1. Add HF_TOKEN in GitHub Secrets
2. Push code to GitHub
3. Pipeline runs automatically
